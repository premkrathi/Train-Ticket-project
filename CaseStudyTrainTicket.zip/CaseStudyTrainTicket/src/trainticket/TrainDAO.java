package trainticket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class TrainDAO {
    
    final static String DRIVER_NAME="oracle.jdbc.OracleDriver";
    final static String DB_URL="jdbc:oracle:thin:@127.0.0.1:1521:XE";
    final static String USERNAME="hr";
    final static String PASSWORD="hr";
    public static Train findTrain(int trainNo) throws ClassNotFoundException, SQLException {
                
                //step 1 - register the driver
                Class.forName(DRIVER_NAME);
                //Step 2 - establish a connection
                Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                //Step 3 - create a statement
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM Trains where train_no="+ trainNo+"");
                boolean found=resultSet.next();
                try{
                        if(!found) {
                    throw new TrainNotFoundException();
                        }
                }catch(TrainNotFoundException e) {
                    System.out.print("Train was not found.\n Plese check your Train Number");
                      return null;
                }
                
                if(found) {
                    Train t=new Train(resultSet.getInt(1),resultSet.getString("TRAIN_NAME"),resultSet.getString("SOURCE"),resultSet.getString("dESTINATION"),resultSet.getDouble(5));    
                  //System.out.print(resultSet.getString(2));
                    return t;
                }
                connection.close();
                return null;
                
               
                
            }
    
            public static void main(String[] args) throws ClassNotFoundException, SQLException {
                // TODO Auto-generated method stub
                
                //Train t= TrainDAO.findTrain(1001);
                //System.out.println(t);
            }
    
    
            
}